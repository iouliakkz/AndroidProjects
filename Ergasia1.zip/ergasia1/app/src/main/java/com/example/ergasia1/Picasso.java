package com.example.ergasia1;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class Picasso extends AppCompatActivity {
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_picasso);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        preferences=getPreferences(MODE_PRIVATE);
        //editPreferences();
    }

    private void editPreferences(){
        SharedPreferences.Editor editor=preferences.edit();
        editor.putString("picassokey_el","Ο κιθαρίστας, αν και μυώδης, δείχνει ελάχιστα σημάδια ζωής και φαίνεται να είναι κοντά στον θάνατο, υπονοώντας λίγη άνεση στον κόσμο και τονίζοντας τη δυστυχία της κατάστασής του. Οι λεπτομέρειες εξαλείφονται και η κλίμακα χειραγωγείται για να δημιουργηθούν επιμήκεις και κομψές αναλογίες ενώ εντείνεται η σιωπηλή ενατένιση του κιθαρίστα και η αίσθηση πνευματικότητας. Η μεγάλη, καφέ κιθάρα είναι η μόνη σημαντική αλλαγή χρώματος που βρέθηκε στον πίνακα. Το θαμπό καφέ του, που φαίνεται στο μπλε φόντο, γίνεται το κέντρο και η εστίαση. Η κιθάρα έρχεται να αντιπροσωπεύσει τον κόσμο του κιθαρίστα και τη μόνη ελπίδα για επιβίωση. Αυτό το τυφλό και φτωχό θέμα εξαρτάται από την κιθάρα του και το μικρό εισόδημα που μπορεί να κερδίσει από τη μουσική του για επιβίωση. Ορισμένοι ιστορικοί τέχνης πιστεύουν ότι αυτός ο πίνακας εκφράζει τη μοναχική ζωή ενός καλλιτέχνη και τους φυσικούς αγώνες που έρχονται με την καριέρα. Ως εκ τούτου, η μουσική, ή τέχνη, γίνεται ένα βάρος και μια αλλοτριωτική δύναμη που απομονώνει τους καλλιτέχνες από τον κόσμο.Ο Παλιός Κιθαρίστας γίνεται αλληγορία της ανθρώπινης ύπαρξης. ");
        editor.putString("picassokey_en","The guitarist, although muscular, shows little sign of life and appears close to death, implying little comfort in the world and emphasizing the misery of his condition. The details are erased, and the scale is manipulated to create elongated and elegant proportions, while the silent contemplation of the guitarist and the sense of spirituality are intensified. The large, brown guitar is the only significant change in color found in the painting. Its muted brown, set against the blue background, becomes the center and focus. The guitar comes to represent the guitarist's world and his only hope for survival. This blind and impoverished subject depends on his guitar and the small income he can earn from his music to survive. Some art historians believe that this painting expresses the lonely life of an artist and the physical struggles that come with the career. Thus, music, or art, becomes a burden and an alienating force that isolates artists from the world. The Old Guitarist becomes an allegory of human existence.");
        editor.apply();
    }

    public void detailspicasso(View view) {
        String language = Locale.getDefault().getLanguage();
        String data;
        if (language.equals("el")) {
            data = preferences.getString("picassokey_el", "NO VALUE");
        } else {
            data = preferences.getString("picassokey_en", "NO VALUE");
        }
        View customView = getLayoutInflater().inflate(R.layout.custom_alertbox, null);
        TextView title = customView.findViewById(R.id.custom_dialog_title);
        TextView message = customView.findViewById(R.id.custom_dialog_message);
        title.setText("The Old Guitarist");
        message.setText(data);
        new AlertDialog.Builder(this)
                .setView(customView)
                .setPositiveButton("OK", (dialog, which) -> {})
                .show();
    }
}
package com.example.ergasia1;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class Aggelos extends AppCompatActivity {
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_aggelos);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        preferences=getPreferences(MODE_PRIVATE);
        //editPreferences();
    }
    private void editPreferences(){
        SharedPreferences.Editor editor=preferences.edit();
        editor.putString("aggeloskey_el","Η Πιετά (ιταλικά Pietà, αγγλικά The Pity, ελληνικά Έλεος, 1497 - 1499) είναι ένα μαρμάρινο γλυπτό της Αναγέννησης, γνωστό και ως «Αποκαθήλωση», που φιλοτεχνήθηκε από τον Μιχαήλ Άγγελο και βρίσκεται στην Βασιλική του Αγίου Πέτρου στην πόλη του Βατικανού. Είναι το πρώτο έργο του καλλιτέχνη που ήταν τότε λίγο μεγαλύτερος από 20 χρόνων το μοναδικό που έχει υπογράψει, και ίσως ένα από τα σπουδαιότερα έργα τέχνης του δυτικού κόσμου.");
        editor.putString("aggeloskey_en","The Pietà (Italian: Pietà, English: The Pity, Greek: Έλεος, 1497 - 1499) is a marble sculpture of the Renaissance, also known as the 'Deposition,' created by Michelangelo and located in St. Peter's Basilica in the city of Vatican City. It is the artist's first work, who was then just over 20 years old, the only one he signed, and perhaps one of the greatest works of art in the Western world.");
        editor.apply();
    }

    public void detailsaggelos(View view) {
        String language = Locale.getDefault().getLanguage();
        String data;
        if (language.equals("el")) {
            data = preferences.getString("aggeloskey_gr", "NO VALUE");
        } else {
            data = preferences.getString("aggeloskey_en", "NO VALUE");
        }

        View customView = getLayoutInflater().inflate(R.layout.custom_alertbox, null);
        TextView title = customView.findViewById(R.id.custom_dialog_title);
        TextView message = customView.findViewById(R.id.custom_dialog_message);
        title.setText("Pieta");
        message.setText(data);
        new AlertDialog.Builder(this)
                .setView(customView)
                .setPositiveButton("OK", (dialog, which) -> {})
                .show();
    }

}
package com.example.ergasia1;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class Leonardo extends AppCompatActivity {
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_leonardo);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });
        preferences=getPreferences(MODE_PRIVATE);
        //editPreferences();
    }
    private void editPreferences(){
        SharedPreferences.Editor editor=preferences.edit();
        editor.putString("leonardokey_el","Η Μόνα Λίζα (γνωστή και ως Τζιοκόντα, ή Πορτραίτο της Λίζα Γκεραρντίνι, συζύγου του Φρανσέσκο ντελ Τζιοκόντο) είναι προσωπογραφία που ζωγράφισε ο Ιταλός καλλιτέχνης Λεονάρντο ντα Βίντσι. Πρόκειται για ελαιογραφία σε ξύλο λεύκης, που ολοκληρώθηκε μέσα στη χρονική περίοδο 1503-1519. Αποτελεί ιδιοκτησία του Γαλλικού Κράτους, και εκτίθεται στο Μουσείο του Λούβρου, στο Παρίσι. Ο πίνακας, διαστάσεων 77 εκ. × 53 εκ., απεικονίζει μία καθιστή γυναίκα, τη Λίζα ντελ Τζοκόντο, η έκφραση του προσώπου της οποίας χαρακτηρίζεται συχνά ως αινιγματική.Η Μόνα Λίζα θεωρείται το πιο διάσημο έργο ζωγραφικής.");
        editor.putString("leonardokey_en","The Mona Lisa (also known as La Gioconda, or Portrait of Lisa Gherardini, wife of Francesco del Giocondo) is a portrait painted by the Italian artist Leonardo da Vinci. It is an oil painting on poplar wood, completed during the period of 1503-1519. It is owned by the French State and is exhibited in the Louvre Museum in Paris. The painting, measuring 77 cm × 53 cm, depicts a seated woman, Lisa del Giocondo, whose facial expression is often described as enigmatic. The Mona Lisa is considered the most famous painting in the world.");
        editor.apply();
    }

    public void detailsleonardo(View view) {
        String language = Locale.getDefault().getLanguage();
        String data;
        if (language.equals("el")) {
            data = preferences.getString("leonardokey_el", "NO VALUE");
        } else {
            data = preferences.getString("leonardokey_en", "NO VALUE");
        }
        View customView = getLayoutInflater().inflate(R.layout.custom_alertbox, null);
        TextView title = customView.findViewById(R.id.custom_dialog_title);
        TextView message = customView.findViewById(R.id.custom_dialog_message);
        title.setText("Mona Lisa");
        message.setText(data);
        new AlertDialog.Builder(this)
                .setView(customView)
                .setPositiveButton("OK", (dialog, which) -> {})
                .show();
    }
}
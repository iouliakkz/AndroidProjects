package com.example.ergasia1;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class VanGogh extends AppCompatActivity {
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_van_gogh);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        preferences=getPreferences(MODE_PRIVATE);
        //editPreferences();
    }
    private void editPreferences(){
        SharedPreferences.Editor editor=preferences.edit();
        editor.putString("vankey_el","Η Έναστρη Νύχτα είναι ελαιογραφία σε καμβά του Ολλανδού μετα-ιμπρεσιονιστή ζωγράφου Βίνσεντ βαν Γκογκ. Φιλοτεχνημένος τον Ιούνιο του 1889, απεικονίζει τη θέα από το δυτικό παράθυρο του δωματίου του στο άσυλο Σεν Ρεμί ντε Προβάνς, μόλις πριν την ανατολή του ηλίου, με την προσθήκη ενός εξιδανικευμένου χωριού. Εκτίθεται στην μόνιμη συλλογή του Μουσείου Μοντέρνας Τέχνης στην Νέα Υόρκη από το 1941 και αποκτήθηκε μέσω του κληροδοτήματος Λίλι Π. Μπλις. Θεωρείται ένα από τα καλύτερα έργα του Βαν Γκογκ και είναι ένας από τους πιο γνωστούς πίνακες στην ιστορία του Δυτικού πολιτισμού.");
        editor.putString("vankey_en","The Starry Night is an oil painting on canvas by the Dutch post-impressionist painter Vincent van Gogh. Painted in June 1889, it depicts the view from the west-facing window of his room at the Saint-Paul-de-Mausole asylum in Saint-Rémy-de-Provence, just before sunrise, with the addition of an idealized village. It has been part of the permanent collection of the Museum of Modern Art in New York since 1941 and was acquired through the Lily P. Bliss bequest. It is considered one of van Gogh's finest works and is one of the most famous paintings in the history of Western culture.");
        editor.apply();
    }

    public void detailsvangogh(View view) {
        String language = Locale.getDefault().getLanguage();
        String data;
        if (language.equals("el")) {
            data = preferences.getString("vankey_el", "NO VALUE");
        } else {
            data = preferences.getString("vankey_en", "NO VALUE");
        }
        View customView = getLayoutInflater().inflate(R.layout.custom_alertbox, null);
        TextView title = customView.findViewById(R.id.custom_dialog_title);
        TextView message = customView.findViewById(R.id.custom_dialog_message);
        title.setText("The Starry Night");
        message.setText(data);
        new AlertDialog.Builder(this)
                .setView(customView)
                .setPositiveButton("OK", (dialog, which) -> {})
                .show();
    }
}
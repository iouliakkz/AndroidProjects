package com.example.ergasia1;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.Locale;

public class Botticelli extends AppCompatActivity {
    SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_botticelli);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        preferences=getPreferences(MODE_PRIVATE);
        //editPreferences();
    }

    private void editPreferences(){
        SharedPreferences.Editor editor=preferences.edit();
        editor.putString("botticellikey_el","Βλέπουμε το Θείο Βρέφος στη φάτνη και την Παρθένο Μαρία, σε στάση λατρείας και προσευχής να κοιτάζει γλυκά τον Χριστό. Βλέπουμε, Άγγελοι, ποιμένες , και οι Σοφοί Μάγοι της Ανατολής, να περικυκλώνουν έκπληκτοι το Θαύμα της Γέννησης. Όμως, όσο απλό και να φαίνεται, κάθε κομμάτι του πίνακα κρύβει και έναν βαθύ ΣΥΜΒΟΛΙΣΜΟ. Γι’ αυτό λέγεται «Μυστική Γέννηση»! Αφανέρωτη, ανεξήγητη, γι αυτόν που δυσκολεύεται ή δεν μπορεί να τη διαβάσει. Και αυτό συμβαίνει, γιατί με τη Γέννηση, στον πίνακα υπονοείται και η Μελλοντική Δευτέρα Παρουσία, σύμφωνα με τις Χριστιανικές Γραφές. Δηλαδή, η μελλοντική δεύτερη αυτή τη φορά εμφάνιση του Χριστού. Η συντέλεια των αιώνων, το Τέλος του Χώρου και του Χρόνου.");
        editor.putString("botticellikey_en","We see the Divine Infant in the manger and the Virgin Mary, in a posture of worship and prayer, gazing sweetly at Christ. We see angels, shepherds, and the Wise Men of the East, surrounding the Miracle of the Nativity in astonishment. However, no matter how simple it may seem, every piece of the painting conceals a profound SYMBOLISM. This is why it is called the 'Mystical Nativity'! Hidden, inexplicable, to those who struggle to interpret it or cannot read it at all. This happens because with the Nativity, the painting also implies the Future Second Coming, according to Christian Scriptures. That is, the future second appearance of Christ. The culmination of the ages, the End of Space and Time.");
        editor.apply();
    }
    public void detailsbott(View view) {

        String language = Locale.getDefault().getLanguage();
        String data;
        if (language.equals("el")) {
            data = preferences.getString("botticellikey_el", "NO VALUE");
        } else {
            data = preferences.getString("botticellikey_en", "NO VALUE");
        }
        View customView = getLayoutInflater().inflate(R.layout.custom_alertbox, null);
        TextView title = customView.findViewById(R.id.custom_dialog_title);
        TextView message = customView.findViewById(R.id.custom_dialog_message);
        title.setText("The Mystical Nativity");
        message.setText(data);
        new AlertDialog.Builder(this)
                .setView(customView)
                .setPositiveButton("OK", (dialog, which) -> {})
                .show();
    }
}
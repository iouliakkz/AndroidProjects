package com.example.ergasia1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void goleonardo(View view){
        Intent intent2=new Intent(this,Leonardo.class);
        startActivity(intent2);
    }

    public void gobins(View view){
        Intent intent3=new Intent(this,VanGogh.class);
        startActivity(intent3);
    }

    public void gobotitseli(View view){
        Intent intent4=new Intent(this,Botticelli.class);
        startActivity(intent4);
    }

    public void goaggelos(View view){
        Intent intent5=new Intent(this,Aggelos.class);
        startActivity(intent5);
    }

    public void gopablo(View view){
        Intent intent6=new Intent(this,Picasso.class);
        startActivity(intent6);
    }
}